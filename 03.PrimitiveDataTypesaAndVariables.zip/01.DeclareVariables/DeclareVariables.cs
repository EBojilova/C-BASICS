﻿using System;

class DeclareVariables
{
    static void Main()
    {
        ushort n1 = 52130;
        sbyte n2 = -115;
        uint n3 = 4825932;
        byte n4 = 97;
        short n5 = -10000;
    }
}

