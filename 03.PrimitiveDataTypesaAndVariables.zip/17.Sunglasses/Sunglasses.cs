﻿using System;

class Sunglasses
{
    static void Main()
    {
        //Console.WriteLine("Enter an integer number \"n\" (odd number) = height of sunglasses:");
        ushort n = ushort.Parse(Console.ReadLine());
        string topBottom = new string('*', 2 * n);
        string emptySpace = new string(' ', n);
        string lens = new string('/', n * 2 - 2);
        string bride = new string('|', n);
        string middleFrame = string.Format("{0}{1}{0}{2}{0}{1}{0}", '*', lens,emptySpace);
        string brideFrame = string.Format("{0}{1}{0}{2}{0}{1}{0}", '*', lens, bride);
        string topBottomFrame = string.Format("{0}{1}{0}", topBottom,emptySpace);
        Console.WriteLine(topBottomFrame);
        for (int i = 0; i < (n-3)/2; i++)
        {
            Console.WriteLine(middleFrame);
        }
        Console.WriteLine(brideFrame);
        for (int i = 0; i < (n - 3) / 2; i++)
        {
            Console.WriteLine(middleFrame);
        }
        Console.WriteLine(topBottomFrame);
    }
}

