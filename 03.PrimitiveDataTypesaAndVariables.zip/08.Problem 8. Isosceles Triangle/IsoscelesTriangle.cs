﻿using System;
using System.Text; // We must use this library so we can use the ENCODING property

class IsoscelesTriangle
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.Unicode;
        UTF8Encoding utf8 = new UTF8Encoding();
        //string copywrightX = "\u00a9";
        //string copywright = "©";
        Console.WriteLine("   \u00A9   ");
        Console.WriteLine("  \u00A9 \u00A9  ");
        Console.WriteLine(" \u00A9   \u00A9 ");
        Console.WriteLine("\u00A9 \u00A9 \u00A9 \u00A9");
    }
}
