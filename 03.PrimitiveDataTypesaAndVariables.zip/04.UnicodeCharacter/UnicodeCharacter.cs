﻿using System;

class UnicodeCharacter
{
    static void Main()
    {
        char symbol = '\x2A' ;
        Console.WriteLine(symbol);
    }
}

