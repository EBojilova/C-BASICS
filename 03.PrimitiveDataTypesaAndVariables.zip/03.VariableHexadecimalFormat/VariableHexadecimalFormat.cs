﻿using System;

class VariableHexadecimalFormat
{
    static void Main()
    {
        byte n= 0xFE;
        Console.WriteLine(n);
    }
}

