﻿using System;

class FloatOrDouble
{
    static void Main()
    {
        double n1 = 34.567839023;
        float n2 = 12.345f;
        double n3 = 8923.1234857;
        float n4 = 3456.091f;
        Console.WriteLine(n1);
        Console.WriteLine(n2);
        Console.WriteLine(n3);
        Console.WriteLine(n4);
    }
}

