﻿using System;
using System.Text;

class PrintASCIITable
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.Unicode;
        UTF8Encoding utf8 = new UTF8Encoding();
        for (int i = 0; i < 256; i++)
        {
            Console.WriteLine("The number {0} is {1} in ASCII", i, (char)i);
        }
    }
}

