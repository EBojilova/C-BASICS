﻿using System;

class RandomizeNumbers1toN
    {
        static void Main()
        {
            int n = new int();
            Console.Write("n: ");
            string nStr = Console.ReadLine();
            if (int.TryParse(nStr, out n)) ;
            else
            {
                Console.WriteLine("out of range");
                return;
            }
            Random generatorNums = new Random();
            for (int i = 1; i <= n; i++)
            {
                int numI = generatorNums.Next(1, n + 1);
                Console.Write("{0} ", numI);
            }
        }
    }

