﻿using System;

class CurrentDateAndTime
{
    static void Main(string[] args)
    {
        Console.WriteLine("Current Date And Time are:");
        Console.WriteLine(DateTime.Now);
    }
}
