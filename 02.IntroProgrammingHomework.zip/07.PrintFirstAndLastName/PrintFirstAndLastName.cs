﻿using System;

class PrintFirstAndLastName
{
    static void Main()
    {
        Console.WriteLine("Tosho");
        Console.WriteLine("Toshev");
    }
}

