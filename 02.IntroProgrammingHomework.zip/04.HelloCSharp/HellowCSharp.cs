﻿using System;
 class HellowCSharp
    {
        static void Main()
        {
            Console.WriteLine("HelloCSharp");
        }
    }

