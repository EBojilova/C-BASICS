﻿using System;

class PrintNumbers
{
    static void Main(string[] args)
    {
        Console.WriteLine(1);
        Console.WriteLine(101);
        Console.WriteLine(1001);
    }
}

