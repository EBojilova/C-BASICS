﻿using System;

class CatchBits
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        int step = int.Parse(Console.ReadLine());
        string binaryStr = "";
        string tempNum = "";
        for (int i = 0; i < n; i++)
        {
            int num = int.Parse(Console.ReadLine());
            tempNum = Convert.ToString(num, 2).PadLeft(8, '0');
            binaryStr += tempNum;
        }
        int index = 1;
        char[] bits = binaryStr.ToCharArray();
        binaryStr = "";
        for (int i = 0; i < bits.Length; i++)
        {
            if (i == index)
            {
                index += step;
                binaryStr += bits[i];
            }
        }
        if (binaryStr.Length % 8 != 0)
        {
            binaryStr += new string('0', 8 - (binaryStr.Length % 8));
        }
        for (int i = 0; i < binaryStr.Length; i += 8)
        {
            string substringNumber = binaryStr.Substring(i, 8);
            Console.WriteLine(Convert.ToUInt32(substringNumber, 2));
        }
    }
}




/*using System;
using System.Collections.Generic;
using System.Text;

class Program
{
    static void Main()
    {
        int n, step, num = new int();
        //Console.Write("range [1…100] n: ");
        string nStr = Console.ReadLine();
        if (int.TryParse(nStr, out n)) ;
        else
        {
            Console.WriteLine("out of range");
            return;
        }
        //Console.Write("range [1…200] step: ");
        string stepStr = Console.ReadLine();
        if (int.TryParse(stepStr, out step)) ;
        else
        {
            Console.WriteLine("out of range");
            return;
        }
        List<string> numBinaryAll = new List<string>();
        List<char> numExtract = new List<char>();
        for (int i = 1; i <= n; i++)
        {
            //Console.Write("range [1…255] n numbers: ");
            string numStr = Console.ReadLine();
            if (int.TryParse(numStr, out num))
            {
                string numBinary = Convert.ToString(num, 2).PadLeft(8, '0');
                Console.WriteLine(numBinary);
                numBinaryAll.Add(numBinary);
            }
            else
            {
                Console.WriteLine("out of range");
                return;
            }
        }
        StringBuilder builder1 = new StringBuilder();
        foreach (string binary in numBinaryAll)
        {
            builder1.Append(binary).Append("");
        }
        string allBinary = builder1.ToString();
        Console.WriteLine("Binary number after joining: {0}", allBinary);
        int countExtractBits = (int)(((n * 8 - 2) / step) + 1);
        Console.WriteLine("Bits to extract: " + countExtractBits);
        //Dava mi greshno izpisvane s 2 nuli v poveche pri n=2 i s 4 nuli v poveche pri n=3. Ne moga da opredelia ot kade idva greshkata
        for (int k = 0; k < n*8; k -=step)
        {
            numExtract.Add(allBinary[k]);

        }
        StringBuilder builder = new StringBuilder();
        foreach (char number in numExtract)
        {
            builder.Append(number).Append("");
        }
        string resultStr = builder.ToString();
        string added0 = null;
        if (countExtractBits <= 8)
        {
            added0 = new string('0', (countExtractBits % 8));
        }
        else
        {
            added0 = new string('0', (8 - countExtractBits % 8));
        }
        StringBuilder resultAnd0 = new StringBuilder();
        resultAnd0.Append(resultStr);
        resultAnd0.Append(added0);
        String strResult = resultAnd0.ToString();
        int counterBinary = strResult.Length / 8;
        Console.WriteLine(resultAnd0);
        int result = Convert.ToInt32(strResult, 2);
        Console.WriteLine(result);


    }
}
*/

