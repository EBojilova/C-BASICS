﻿using System;

class ModifyBitAtGivenPosition
{
    static void Main()
    {
        Console.WriteLine("n: ");
        int n = Convert.ToInt32(Console.ReadLine());
        Console.Write("p: ");
        int p = Convert.ToInt32(Console.ReadLine());
        Console.Write("v: ");
        int v = Convert.ToInt32(Console.ReadLine());
        if (v == 1)
        {
            int maskLeftP = 1 << p;
            Console.Write(n | maskLeftP);

        }
        else
        {
            int maskLeftP = ~(1 << p);
            int newN = n | maskLeftP;
            Console.WriteLine(n & maskLeftP);
        }
    }
}

