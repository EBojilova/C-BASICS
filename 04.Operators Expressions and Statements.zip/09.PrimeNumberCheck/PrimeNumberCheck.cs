﻿using System;

class PrimeNumberCheck
{
    static void Main()
    {
        int k = 0;
        Console.WriteLine("Please enter a number:");
        int number = Convert.ToInt32(Console.ReadLine());
        for (int i = 1; i <= number; i++)
        {
            if (number % i == 0)
            {
                k++;
            }
        }
        Console.WriteLine(k == 2);
    }
}

