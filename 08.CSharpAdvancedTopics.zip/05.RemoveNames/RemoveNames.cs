﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.RemoveNames
{
    class RemoveNames
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split(' ');
            char[] first = input[0].ToCharArray();
            char[] second = input[1].ToCharArray();
            string command = input[3];

            List<char> newArray = new List<char>();
            for (int i = 0; i < first.Length; i++)
            {
                newArray.Add(first[i]);
            }
            for (int i = 0; i < second.Length; i++)
            {

                newArray.RemoveAll(item => item == second[i]);
            }
            foreach (var letter in newArray)
            {
                Console.Write("{0} ", letter);
            }
            Console.WriteLine();
        }
    }
}
